package king.lib.access;

import java.applet.Applet;
import java.net.URL;

/**
 * Provides basic functionality for applet programs.
 *
 * @author   king
 * @since    January 10, 2007
 */
public class AccessApplet extends Access {
  
  /** The applet to be used for access to images etc. */
  private Applet applet;
  
  /** The scenario dir for this application. */
  private String scenarioDir;
  /** The extra dir. */
  private String extraDir;
  /** The extra remote dir (remote URL). */
  private String extraRemoteDir;

  
  /**
   * Constructor for this object. Enables access to applet functionality. Hides
   * the applet.
   * 
   * @param applet  The applet where to get access to images etc.
   */
  public AccessApplet(Applet applet) {
    this.applet = applet;
    
    // find the scenario dir
    this.scenarioDir = System.getProperty("user.home") 
                     + "/" + applet.getParameter("webstart.dir")
                     + "/" + "scenario";
    this.extraDir = System.getProperty("user.home") 
                     + "/" + applet.getParameter("webstart.dir")
                     + "/" + "extra";
    this.extraRemoteDir = applet.getParameter("webstart.extra.dir");
    
    // NOTE: compare to AccessWebstart
    //       -> does not deploy any files!
  }
  
  /** 
   * Returns the scenario directory. Depending if started e.g. with web start (user.home)
   * or as application ("scenario").
   * 
   * @return  The scenario directory with the scenario files.
   */
  public String getScenarioDir() {
    return this.scenarioDir;
  }
  
  /**
   * Returns the extra directory. Depending if started e.g. with web start (user.home)
   * or as application ("extra").
   * 
   * @return  The extra directory with the extra files.
   */
  public final String getExtraDir() {
    return this.extraDir;
  }
  
  /**
   * Returns the remote location for extra files.
   * 
   * @return  Extra dir remote location or null if not available.
   */
  public String getExtraRemoteDir() {
    return this.extraRemoteDir;
  }
  
  /**
   * Opens the given URL in the browser.
   * 
   * @param url  The URL to open.
   * @throws AccessException  If something goes wrong.
   */
  public void openURL(String url) throws AccessException {
    try {
      applet.getAppletContext().showDocument(new URL(url));
    }
    catch (java.net.MalformedURLException e) {
      throw new AccessException("Malformed URL: " + e);
    }
  }
}
