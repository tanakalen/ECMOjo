package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import java.util.ArrayList;
import java.util.List;
import edu.hawaii.jabsom.tri.ecmo.app.module.Machine;

/**
 * The JOSTRA. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class Jostra implements Machine {

  /** The JOSTRA components. */
  private List<JostraComponent> components = new ArrayList<JostraComponent>();

  
  /**
   * Setup of default configuration.
   */
  public Jostra() {
    // add components
    components.add(new JostraConsole());
    components.add(new JostraPump());
    components.add(new JostraHeater());
    components.add(new JostraACT());
    components.add(new JostraGasFlow());    
    components.add(new JostraFlowMeter());
    components.add(new JostraCDI());
  }
  
  /**
   * Returns all the components.
   * 
   * @return  The components.
   */
  public List<JostraComponent> getComponents() {
    return components;
  }

  /**
   * Returns the component with the given name.
   * 
   * @param name  The name of the component.
   * @return  The component or null if not found.
   */
  public JostraComponent getComponent(String name) {
    for (JostraComponent component: components) {
      if (component.getName().equalsIgnoreCase(name)) {
        return component;
      }
    }
    return null;
  }
  
  /**
   * Sets all the components.
   * 
   * @param components  The components.
   */
  public void setComponents(List<JostraComponent> components) {
    this.components = components;
  }
}
