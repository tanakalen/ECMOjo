package edu.hawaii.jabsom.tri.ecmo.app.state;

import edu.hawaii.jabsom.tri.ecmo.app.module.Machine;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.Jostra;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraPanel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.NumberFormat;
import king.lib.access.ImageLoader;

/**
 * The active state panel. 
 *
 * @author   king
 * @since    January 11, 2007
 */
public class ActiveStatePanel extends JPanel implements Runnable {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/InterfaceBG.jpg");

  /** The state. */
  private ActiveState state;
  
  /** The thread that updates the time. */
  private Thread thread;

  
  /**
   * Constructor for panel. 
   * 
   * @param state  The state for this panel.
   */
  public ActiveStatePanel(ActiveState state) {
    this.state = state;
    
    // set layout
    setLayout(new BorderLayout());
    setOpaque(true);
    
    // add jostra panel
    Machine machine = state.getScenario().getMachine();
    if (machine instanceof Jostra) {
      add(new JostraPanel((Jostra)machine), BorderLayout.CENTER);
    }
    else {
      throw new RuntimeException("Machine not supported: " + state.getScenario().getMachine());
    }
  }
  
  /**
   * Called when panel got added.
   */
  public void addNotify() {
    super.addNotify();
    
    // start updater thread (time display)
    this.thread = new Thread(this);
    this.thread.start();
  }
  
  /**
   * Called when panel go removed.
   */
  public void removeNotify() {
    // stop thread;
    this.thread = null;
    
    super.removeNotify();
  }
  
  /**
   * Updater thread.
   */
  public void run() {
    Thread currentThread = Thread.currentThread();
    while (this.thread == currentThread) {
      // update display
      repaint();
      
      try {
        Thread.sleep(25);
      }
      catch (InterruptedException e) {
        // impossible!
      }
    }
  }
  
  /**
   * Paints this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    Graphics2D g2 = (Graphics2D)g;
    
    // draws the image as background
    g.drawImage(panelImage, 0, 0, this);
    
    // set rendering anti-aliased
    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

    // draw info text
    g.setColor(Color.BLACK);
    g.setFont(g.getFont().deriveFont(Font.BOLD, 14));
    g.drawString("3 day old. 40 wks gestation. 3.1kg. Dx: PPHN", 160, 39);
    
    // draw time
    double time = ((double)state.getScenario().getTime()) / 1000d;
    NumberFormat formatter = NumberFormat.getInstance();
    formatter.setMaximumFractionDigits(1);
    formatter.setMinimumFractionDigits(1);
    String text = "Time " + formatter.format(time) + "s";
    int textWidth = g.getFontMetrics().stringWidth(text);
    g.drawString(text, 770 - textWidth, 39);
  }
}
