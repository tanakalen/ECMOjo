package edu.hawaii.jabsom.tri.ecmo.app.module;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import king.lib.access.LocalHookup;
import king.lib.out.Error;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.Jostra;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraACT;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraCDI;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraConsole;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraFlowMeter;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraGasFlow;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraHeater;
import edu.hawaii.jabsom.tri.ecmo.app.module.jostra.JostraPump;

/**
 * The scenario. 
 *
 * @author   king
 * @since    February 15, 2007
 */
public class Scenario implements Runnable {

  /** The rows of data. */
  private List<String[]> data = new ArrayList<String[]>();
  /** The machine. */
  private Machine machine;
  
  /** The scenario run thread. */
  private Thread thread;
  /** The time in milliseconds. */
  private long time;
  
  
  /**
   * Constructor for scenario.
   * 
   * @param path  The path to the scenario file.
   * @throws IOException  If problems reading file.
   */
  public Scenario(String path) throws IOException {
    // load scenario
    BufferedReader reader = new BufferedReader(new InputStreamReader(LocalHookup.getInstance().getInputStream(path)));
    String line = reader.readLine();
    
    // read until line is null (EOF)
    while (line != null) {
      String[] columns = line.split(",", -1);
      String[] fixedColumns = new String[columns.length];
      for (int i = 0; i < columns.length; i++) {
        if (columns[i].charAt(0) == '\"') {
          fixedColumns[i] = columns[i].substring(1, columns[i].length() - 1);
        }
        else {
          fixedColumns[i] = columns[i];
        }
      }
      data.add(fixedColumns);
      
      // read next line
      line = reader.readLine();
    }
    reader.close();
    
    // construct machine
    machine = new Jostra();
  }
  
  /**
   * Returns the machine for this scenario.
   * 
   * @return  The machine.
   */
  public Machine getMachine() {
    return this.machine;
  }
  
  /** 
   * Returns the elapsed time in milliseconds.
   * 
   * @return  The elapsed time.
   */
  public long getTime() {
    return this.time;
  }
  
  /**
   * Starts the scenario.
   */
  public void start() {
    this.thread = new Thread(this);
    this.thread.start();
  }
  
  /**
   * Stops the scenario.
   */
  public void stop() {
    this.thread = null;
  }
  
  /**
   * Runs a scenario file.
   */
  public void run() {
    // init data
    String[] devices = data.get(0);
    String[] measures = data.get(1);
    int dataIndex = -1;
    int dataOffset = 2;
    
    // set initial time in [ms]
    time = 0;
    long startTime = System.currentTimeMillis();
    
    Thread currentThread = Thread.currentThread();
    while ((this.thread == currentThread) && ((dataIndex + dataOffset + 1) < data.size())) {
      // loop until stopped
      String[] row0 = null;
      String[] row1 = null;
      if (time >= (Integer.parseInt(data.get(dataIndex + dataOffset + 1)[0]) * 1000)) {
        dataIndex++;
        row0 = data.get(dataIndex + dataOffset);
        row1 = row0;
      }
      else {
        row0 = data.get(dataIndex + dataOffset);
        row1 = data.get(dataIndex + dataOffset + 1);
      }
      long rowDuration = (Long.parseLong(row1[0]) - Long.parseLong(row0[0])) * 1000;
      long rowElapsed = time - (Long.parseLong(row0[0]) * 1000);
      
      // update data
      for (int i = 0; i < devices.length; i++) {
        String device = devices[i];
        String measure = measures[i];
        String value0 = row0[i];
        String value1 = row1[i];
        long valueL = 0;
        try {
          long valueL0 = Long.parseLong(value0);
          long valueL1 = Long.parseLong(value1);
          if (rowDuration == 0) {
            valueL = valueL0;
          }
          else {
            valueL = valueL0 + ((valueL1 - valueL0) * rowElapsed / rowDuration);
          }
        }
        catch (NumberFormatException e) {
          // ignore
        }
        double valueD = 0;
        try {
          double valueD0 = Double.parseDouble(value0);
          double valueD1 = Double.parseDouble(value1);
          if (rowDuration == 0) {
            valueD = valueD0;
          }
          else {
            valueD = valueD0 + ((valueD1 - valueD0) * rowElapsed / rowDuration);
          }
        }
        catch (NumberFormatException e) {
          // ignore
        }
        
        if (device.equalsIgnoreCase("Time")) {
          // do not parse ...
        }
        else if (device.equalsIgnoreCase("Console")) {
          JostraConsole console = (JostraConsole)((Jostra)machine).getComponent("Console");
          if (measure.equalsIgnoreCase("Pre-memb Pressure")) {
            console.setPreMembPressure(valueD);
          }
          else if (measure.equalsIgnoreCase("Post-memb Pressure")) {
            console.setPostMembPressure(valueD);
          }
          else if (measure.equalsIgnoreCase("Temperature")) {
            console.setTemperature(valueD);
          }
          else if (measure.equalsIgnoreCase("Bubble Detector")) {
            console.setBubbleDetectorAlarm(value0.equalsIgnoreCase("Alarm"));
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("Pump")) {
          JostraPump pump = (JostraPump)((Jostra)machine).getComponent("Pump");
          if (measure.equalsIgnoreCase("RPM")) {
            pump.setRpm((int)valueL);
          }
          else if (measure.equalsIgnoreCase("Flow")) {
            pump.setFlow(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("Transonic Flow")) {
          JostraFlowMeter flowMeter = (JostraFlowMeter)((Jostra)machine).getComponent("Flow Meter");
          if (measure.equalsIgnoreCase("Flow")) {
            flowMeter.setFlow(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("Gas Flow")) {
          JostraGasFlow gasFlow = (JostraGasFlow)((Jostra)machine).getComponent("Gas Flow");
          if (measure.equalsIgnoreCase("O2 Flow")) {
            gasFlow.setO2Flow(valueD);
          }
          else if (measure.equalsIgnoreCase("FiO2")) {
            gasFlow.setFiO2(valueD);
          }
          else if (measure.equalsIgnoreCase("CO2 Flow")) {
            gasFlow.setCO2Flow(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("CDI")) {
          JostraCDI cdi = (JostraCDI)((Jostra)machine).getComponent("CDI");
          if (measure.equalsIgnoreCase("pH")) {
            cdi.setPH(valueD);
          }
          else if (measure.equalsIgnoreCase("pCO2")) {
            cdi.setPCO2(valueD);
          }
          else if (measure.equalsIgnoreCase("pO2")) {
            cdi.setPO2(valueD);
          }
          else if (measure.equalsIgnoreCase("Temp")) {
            cdi.setTemperature(valueD);
          }
          else if (measure.equalsIgnoreCase("HCO3")) {
            cdi.setHCO3(valueD);
          }
          else if (measure.equalsIgnoreCase("BE")) {
            cdi.setBE(valueD);
          }
          else if (measure.equalsIgnoreCase("Saturation")) {
            cdi.setSaturation(valueD);
          }
          else if (measure.equalsIgnoreCase("Hct")) {
            cdi.setHct(valueD);
          }
          else if (measure.equalsIgnoreCase("Hgb")) {
            try {
              cdi.setHgb(valueD);
            }
            catch (NumberFormatException e) {
              cdi.setHgb(Double.MIN_VALUE);
            }
          }
          else if (measure.equalsIgnoreCase("SO2")) {
            cdi.setSO2(valueD);
          }
          else if (measure.equalsIgnoreCase("K")) {
            cdi.setK(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("ACT")) {
          JostraACT act = (JostraACT)((Jostra)machine).getComponent("ACT");
          if (measure.equalsIgnoreCase("ACT Value")) {
            act.setValue(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else if (device.equalsIgnoreCase("Heater")) {
          JostraHeater heater = (JostraHeater)((Jostra)machine).getComponent("Heater");
          if (measure.equalsIgnoreCase("Temp")) {
            heater.setTemperature(valueD);
          }
          else {
            // measurement not supported:
            Error.out("Measurement not supported by scenario: " + measure + " (" + device + ")");
          }
        }
        else {
          // device not supported
          Error.out("Device not supported by scenario: " + device);
        }
      }
      
      try {
        Thread.sleep(40);
      }
      catch (InterruptedException e) {
        // impossible ...
      }
      
      // update time
      time = System.currentTimeMillis() - startTime;
    }
  }
}
