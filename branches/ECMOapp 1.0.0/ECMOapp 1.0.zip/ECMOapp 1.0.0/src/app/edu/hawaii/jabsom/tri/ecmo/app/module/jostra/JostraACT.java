package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA ACT.
 * 
 * @author king
 * @since January 23, 2007
 */
public class JostraACT implements JostraComponent {

  /** The ACT value. */
  private double value;

  /**
   * Gets the value.
   *
   * @return the value
   */
  public double getValue() {
    return value;
  }

  /**
   * Sets the value.
   *
   * @param value the value to set
   */
  public void setValue(double value) {
    this.value = value;
  }

  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "ACT";
  }
}
