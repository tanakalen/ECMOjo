package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA component definition. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public interface JostraComponent {

  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  String getName();
}
