package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import king.lib.out.Error;

/**
 * The JOSTRA component panel. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraComponentPanel extends JPanel {

  /**
   * Constructor for panel. 
   * 
   * @param component  The component of this panel.
   */
  public JostraComponentPanel(JostraComponent component) {
    // set layout
    setLayout(new BorderLayout());
    setOpaque(false);
    
    // add jostra component
    JPanel componentPanel;
    if (component instanceof JostraConsole) {
      componentPanel = new JostraConsolePanel();
      ((JostraConsolePanel)componentPanel).setConsole((JostraConsole) component);
    }
    else if (component instanceof JostraPump) {
      componentPanel = new JostraPumpPanel();
      ((JostraPumpPanel)componentPanel).setPump((JostraPump) component);
    }
    else if (component instanceof JostraHeater) {
      componentPanel = new JostraHeaterPanel();
      ((JostraHeaterPanel)componentPanel).setHeater((JostraHeater) component);
    }
    else if (component instanceof JostraACT) {
      componentPanel = new JostraACTPanel();
      ((JostraACTPanel)componentPanel).setAct((JostraACT) component);
    }
    else if (component instanceof JostraGasFlow) {
      componentPanel = new JostraGasFlowPanel();
      ((JostraGasFlowPanel)componentPanel).setGasFlow((JostraGasFlow) component);
    }    
    else if (component instanceof JostraFlowMeter) {
      componentPanel = new JostraFlowMeterPanel();
      ((JostraFlowMeterPanel)componentPanel).setFlowMeter((JostraFlowMeter) component);
    }     
    else if (component instanceof JostraCDI) {
      componentPanel = new JostraCDIPanel();
      ((JostraCDIPanel)componentPanel).setCdi((JostraCDI) component);
    }
    else {
      Error.out("Panel not available for: " + component);
      componentPanel = null;
    }
    if (componentPanel != null) {
      // add component and adjust this component's size
      add(componentPanel, BorderLayout.CENTER);
      Dimension size = componentPanel.getPreferredSize();
      setPreferredSize(size);
      setSize(size);
    }
  }
}
