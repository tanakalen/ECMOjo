package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA control console panel. 
 *
 * @author   king
 * @since    January 16, 2007
 */
public class JostraConsolePanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraControlConsole.png");
  /** the console. */
  private JostraConsole console;
  
  /**
   * Constructor for panel. 
   */
  public JostraConsolePanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    // draws the image as background
    Graphics2D g2d = (Graphics2D) g;
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.8f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 12));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat consoleFormat = new DecimalFormat("0.0");
    String text = "" + ((int)console.getPreMembPressure());
    int textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 204 - textWidth, 134);
    text = "" + ((int)console.getPostMembPressure());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 294 - textWidth, 134);
    text = consoleFormat.format(console.getTemperature());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 381 - textWidth, 134);
  }

  /**
   * Gets the console data.
   * 
   * @return the console
   */
  public JostraConsole getConsole() {
    return console;
  }

  /**
   * Sets teh console data.
   * 
   * @param console the console to set
   */
  public void setConsole(JostraConsole console) {
    this.console = console;
  }
}
