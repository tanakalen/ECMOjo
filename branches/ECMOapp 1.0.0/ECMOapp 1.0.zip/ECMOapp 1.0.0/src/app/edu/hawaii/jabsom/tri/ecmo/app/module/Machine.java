package edu.hawaii.jabsom.tri.ecmo.app.module;

/**
 * The machine. 
 *
 * @author   king
 * @since    January 11, 2007
 */
public interface Machine {
  // not needed
}
