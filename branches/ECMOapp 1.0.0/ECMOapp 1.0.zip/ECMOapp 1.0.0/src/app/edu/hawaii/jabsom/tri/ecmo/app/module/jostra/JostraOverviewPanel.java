package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import king.lib.access.ImageLoader;
import king.lib.out.Error;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;

/**
 * The JOSTRA overview panel. 
 *
 * @author   king
 * @since    January 16, 2007
 */
public class JostraOverviewPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraCart.png");
  
  /** The selected area index. -1 for none. */
  private int selectedIndex = -1;
  /** The selected state. */
  private boolean selectedPressed = false;
  /** Define the areas for each of the components. */
  private List<Rectangle> areas = new ArrayList<Rectangle>();

  /** The listeners. */
  private List<JostraOverviewListener> listeners = new ArrayList<JostraOverviewListener>();
  
  
  /**
   * Constructor for panel. 
   * 
   * @param jostra  The whole JOSTRA.
   */
  public JostraOverviewPanel(final Jostra jostra) {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    Dimension size = new Dimension(panelImage.getWidth(this), panelImage.getHeight(this));
    setPreferredSize(size);
    setSize(size);
    
    // map components to coordinates
    for (JostraComponent component: jostra.getComponents()) {
      if (component instanceof JostraConsole) {
        areas.add(new Rectangle(285, 94, 53, 52));
      }
      else if (component instanceof JostraPump) {
        areas.add(new Rectangle(236, 215, 32, 52));
      }
      else if (component instanceof JostraHeater) {
        areas.add(new Rectangle(269, 184, 47, 83));
      }
      else if (component instanceof JostraACT) {
        areas.add(new Rectangle(247, 57, 36, 24));
      }
      else if (component instanceof JostraGasFlow) {
        areas.add(new Rectangle(286, 55, 18, 36));
      }
      else if (component instanceof JostraFlowMeter) {
        areas.add(new Rectangle(245, 82, 39, 15));
      }
      else if (component instanceof JostraCDI) {
        areas.add(new Rectangle(170, 35, 52, 41));
      }
      else {
        Error.out("JOSTRA Overview - JOSTRA component not supported: " + component);
        areas.add(new Rectangle(0, 0, -1, -1));
      }
    }
    
    // add motion listener
    this.addMouseMotionListener(new MouseMotionAdapter() {  
      public void mouseMoved(MouseEvent event) {
        int x = event.getX();
        int y = event.getY();
        int index = -1;
        for (int i = 0; i < areas.size(); i++) {
          Rectangle area = areas.get(i);
          if ((x >= area.x) && (x <= area.x + area.width) && (y >= area.y) && (y <= area.y + area.height)) {
            index = i;
          }
        }
        if (selectedIndex != index) {
          selectedIndex = index;
          repaint();
        }
      }
    });
    
    // add key listener
    this.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent event) {
        selectedPressed = true;
        repaint();
      }
      public void mouseReleased(MouseEvent arg0) {
        selectedPressed = false;
        repaint();
        int index = selectedIndex;
        if (index >= 0) {
          JostraComponent selection = jostra.getComponents().get(index);
          for (JostraOverviewListener listener: listeners) {
            listener.componentSelected(selection);
          }
        }
      }     
    });
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    // draws the image as background
    g.drawImage(panelImage, 0, 0, this);

    // highlight selected area
    int index = selectedIndex;
    if (index >= 0) {
      if (selectedPressed) {
        g.setColor(new Color(1.0f, 0.0f, 0.0f, 0.3f));
      }
      else {
        g.setColor(new Color(1.0f, 1.0f, 0.0f, 0.3f));
      }
      Rectangle area = areas.get(index);
      g.fillRect(area.x, area.y, area.width, area.height);
    }
  }
  
  /**
   * Adds a listener.
   * 
   * @param listener  The listener to add.
   */
  public void addListener(JostraOverviewListener listener) {
    this.listeners.add(listener);
  }
  
  /**
   * Removes a listener.
   * 
   * @param listener  The listener to remove.
   */
  public void removeListener(JostraOverviewListener listener) {
    this.listeners.remove(listener);
  }
}
