package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA gas flow (or Oxigen). 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraGasFlow implements JostraComponent {
  /** The O2 flow (liter per min). */
  private double o2Flow;
  /** The FiO2. */
  private double fiO2;
  /** The CO2 flow (liter per min). */
  private double cO2Flow;
  
  /**
   * Gets the cO2Flow.
   *
   * @return the cO2Flow
   */
  public double getCO2Flow() {
    return cO2Flow;
  }
  
  /**
   * Sets the cO2Flow.
   *
   * @param flow the cO2Flow to set
   */
  public void setCO2Flow(double flow) {
    cO2Flow = flow;
  }
  
  /**
   * Gets the fiO2.
   *
   * @return the fiO2
   */
  public double getFiO2() {
    return fiO2;
  }
  
  /**
   * Sets the fiO2.
   *
   * @param fiO2 the fiO2 to set
   */
  public void setFiO2(double fiO2) {
    this.fiO2 = fiO2;
  }
  
  /**
   * Gets the o2Flow.
   *
   * @return the o2Flow
   */
  public double getO2Flow() {
    return o2Flow;
  }
  
  /**
   * Sets the o2Flow.
   *
   * @param flow the o2Flow to set
   */
  public void setO2Flow(double flow) {
    o2Flow = flow;
  }
  
  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "Gas Flow";
  }
}
