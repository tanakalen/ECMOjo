package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA CDI panel. 
 *
 * @author   king
 * @since    February 12, 2007
 */
public class JostraCDIPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraCDI.png");
  /** The CDI. */
  private JostraCDI cdi;
  
  /**
   * Constructor for panel. 
   */
  public JostraCDIPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    // draws the image as background
    Graphics2D g2d = (Graphics2D) g;
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.0f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 14));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat cdiFormat0 = new DecimalFormat("0");
    DecimalFormat cdiFormat1 = new DecimalFormat("0.0");
    DecimalFormat cdiFormat2 = new DecimalFormat("0.00");
    String text = cdiFormat2.format(cdi.getPH());
    int textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 238);
    text = cdiFormat0.format(cdi.getPCO2());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 268);
    text = cdiFormat0.format(cdi.getPO2());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 295);
    text = cdiFormat1.format(cdi.getTemperature());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 324);
    text = cdiFormat0.format(cdi.getHCO3());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 350);
    text = cdiFormat1.format(cdi.getBE());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 379);
    text = cdiFormat0.format(cdi.getSaturation());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 210 - textWidth, 405);
    text = cdiFormat0.format(cdi.getHct());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 340 - textWidth, 238);
    text = cdiFormat0.format(cdi.getSO2());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 340 - textWidth, 295);
    text = cdiFormat1.format(cdi.getK());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 340 - textWidth, 324);
  }

  /**
   * Gets the CDI.
   * 
   * @return the cdi
   */
  public JostraCDI getCdi() {
    return cdi;
  }

  /**
   * Sets the CDI.
   * 
   * @param cdi the cdi to set
   */
  public void setCdi(JostraCDI cdi) {
    this.cdi = cdi;
  }
}
