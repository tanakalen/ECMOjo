package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA heater. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraHeater implements JostraComponent {
  /** The temperature. */
  private double temperature;

  /**
   * Gets the temperature.
   *
   * @return the temperature
   */
  public double getTemperature() {
    return temperature;
  }

  /**
   * Sets the temperature.
   *
   * @param temperature the temperature to set
   */
  public void setTemperature(double temperature) {
    this.temperature = temperature;
  }
  
  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "Heater";
  }
}
