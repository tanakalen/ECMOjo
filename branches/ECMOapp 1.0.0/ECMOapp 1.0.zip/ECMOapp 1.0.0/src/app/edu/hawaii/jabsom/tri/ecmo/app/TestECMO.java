package edu.hawaii.jabsom.tri.ecmo.app;

import junit.framework.TestCase;

/**
 * Test test :-).
 * 
 * @author Christoph Aschwanden
 */
public class TestECMO extends TestCase {

  /** The empty list. */
  private java.util.List emptyList;
 
  /**
   * Sets up the test fixture. 
   * (Called before every test case method.) 
   */
  protected void setUp() {
    emptyList = new java.util.ArrayList();
  }

  /**
   * Tears down the test fixture. 
   * (Called after every test case method.) 
   */
  protected void tearDown() {
    emptyList = null;
  }

  /**
   * Tests some behavior.
   */
  public void testSomeBehavior() {
    assertEquals("Empty list should have 0 elements", 0, emptyList.size());
  }

  /**
   * Tests exceptions.
   */
  public void testForException() {
    try {
      Object o = emptyList.get(0);
      fail("Should raise an IndexOutOfBoundsException");
    } 
    catch (IndexOutOfBoundsException success) {
      // not used
    }
  }
}