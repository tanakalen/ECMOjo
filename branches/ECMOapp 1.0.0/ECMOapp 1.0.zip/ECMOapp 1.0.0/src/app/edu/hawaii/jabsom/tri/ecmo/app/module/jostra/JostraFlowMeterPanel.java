package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA flow meter panel. 
 *
 * @author   king
 * @since    February 12, 2007
 */
public class JostraFlowMeterPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraFlowMeter.png");
  /** The flow meter. */
  private JostraFlowMeter flowMeter;
  
  /**
   * Constructor for panel. 
   */
  public JostraFlowMeterPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
    // draws the image as background
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.8f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 54));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat flowMeterFormat = new DecimalFormat("0.000");
    String text = flowMeterFormat.format(flowMeter.getFlow());
    int textWidth = g2d.getFontMetrics().stringWidth(text);    
    g2d.drawString(text, 470 - textWidth, 328);
  }

  /**
   * Gets the flowMeter.
   *
   * @return the flowMeter
   */
  public JostraFlowMeter getFlowMeter() {
    return flowMeter;
  }

  /**
   * Sets the flowMeter.
   *
   * @param flowMeter the flowMeter to set
   */
  public void setFlowMeter(JostraFlowMeter flowMeter) {
    this.flowMeter = flowMeter;
  }
}