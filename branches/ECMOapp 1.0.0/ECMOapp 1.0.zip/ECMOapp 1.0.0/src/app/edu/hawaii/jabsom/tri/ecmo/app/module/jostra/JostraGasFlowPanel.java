package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import king.lib.access.ImageLoader;

/**
 * The JOSTRA gas flow panel. 
 *
 * @author   king
 * @since    February 12, 2007
 */
public class JostraGasFlowPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraGasFlow.png");
  /** The gas ball image. */
  private Image gasBallImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraGasBall.png");
  
  /** The gas flow. */
  private JostraGasFlow gasFlow;
  
  
  /**
   * Constructor for panel. 
   */
  public JostraGasFlowPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    // draws the image as background
    g.drawImage(panelImage, 0, 0, this);

    // draws the gas balls
    g.setClip(211, 121, 48, 422);
    double co2Flow = gasFlow.getCO2Flow();
    g.drawImage(gasBallImage, 227, (int)(525 - (co2Flow * 10 * 33)), this);
    g.setClip(null);
    
    // O2 flows
    double o2Flow = gasFlow.getO2Flow();
    int o2Pixels = 0;
    if (o2Flow < 0.2) {
      o2Pixels = (int)(o2Flow * 84 / 0.2d);
    }
    else if (o2Flow < 0.4) {
      o2Pixels = 84 + (int)((o2Flow - 0.2) * 43 / 0.2d);
    }
    else if (o2Flow < 0.6) {
      o2Pixels = 84 + 43 + (int)((o2Flow - 0.4) * 33 / 0.2d);
    }
    else if (o2Flow < 0.8) {
      o2Pixels = 84 + 43 + 33 + (int)((o2Flow - 0.6) * 27 / 0.2d);
    }
    else {
      o2Pixels = 84 + 43 + 33 + 27 + (int)((o2Flow - 0.8) * 23 / 0.2d);
    }
    g.drawImage(gasBallImage, 324, 544 - o2Pixels, this);
    
    // fiO2 flows
    double fio2Flow = gasFlow.getFiO2();
    g.drawImage(gasBallImage, 389, (int)(544 - (fio2Flow * 39)), this);
  }

  /**
   * Gets the gasFlow.
   *
   * @return the gasFlow
   */
  public JostraGasFlow getGasFlow() {
    return gasFlow;
  }

  /**
   * Sets the gasFlow.
   *
   * @param gasFlow the gasFlow to set
   */
  public void setGasFlow(JostraGasFlow gasFlow) {
    this.gasFlow = gasFlow;
  }
}
