package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA console.
 * 
 * @author king
 * @since January 23, 2007
 */
public class JostraConsole implements JostraComponent {
  
  /** the pre-memb pressure. */
  private double preMembPressure;
  /** the post-memb pressure. */
  private double postMembPressure;
  /** the temperature. */
  private double temperature;
  /** the bubble detector alarm. */
  private boolean bubbleDetectorAlarm;
  
  /**
   * Gets pre-memb pressure.
   * 
   * @return the preMembPressure
   */
  public double getPreMembPressure() {
    return preMembPressure;
  }

  /**
   * Sets the pre-memb pressure.
   * 
   * @param preMembPressure the preMembPressure to set
   */
  public void setPreMembPressure(double preMembPressure) {
    this.preMembPressure = preMembPressure;
  }

  /**
   * Gets post-memb pressure.
   * 
   * @return the postMembPressure
   */
  public double getPostMembPressure() {
    return postMembPressure;
  }

  /**
   * Sets post-memb pressure.
   * 
   * @param postMembPressure the postMembPressure to set
   */
  public void setPostMembPressure(double postMembPressure) {
    this.postMembPressure = postMembPressure;
  }

  /**
   * Gets the temperature.
   * 
   * @return the temperature
   */
  public double getTemperature() {
    return temperature;
  }

  /**
   * Sets the temperature.
   * 
   * @param temperature the temperature to set
   */
  public void setTemperature(double temperature) {
    this.temperature = temperature;
  }

  /**
   * Check the bubble detector alarm is on or off.
   * 
   * @return the bubbleDetectorAlarm
   */
  public boolean isBubbleDetectorAlarm() {
    return bubbleDetectorAlarm;
  }

  /**
   * Sets the bubble detector alarm is on or off.
   * 
   * @param bubbleDetectorAlarm the bubbleDetectorAlarm to set
   */
  public void setBubbleDetectorAlarm(boolean bubbleDetectorAlarm) {
    this.bubbleDetectorAlarm = bubbleDetectorAlarm;
  }

  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "Console";
  }
}
