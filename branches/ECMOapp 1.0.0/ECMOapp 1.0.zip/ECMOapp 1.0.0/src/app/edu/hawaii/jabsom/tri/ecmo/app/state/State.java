package edu.hawaii.jabsom.tri.ecmo.app.state;

/**
 * The state. 
 *
 * @author   king
 * @since    January 11, 2007
 */
public abstract class State {

}
