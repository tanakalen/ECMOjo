package edu.hawaii.jabsom.tri.ecmo.app.state;

/**
 * The state machine. 
 *
 * @author   king
 * @since    January 10, 2007
 */
public class StateMachine {

  /** The currently active state. */
  private State state = new ActiveState();
  
  
  /**
   * Returns the current state.
   * 
   * @return  The current state.
   */
  public State currentState() {
    return this.state;
  }
}
