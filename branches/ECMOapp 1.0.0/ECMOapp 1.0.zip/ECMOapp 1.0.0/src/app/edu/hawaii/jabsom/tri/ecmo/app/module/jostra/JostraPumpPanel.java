package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA pump panel. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraPumpPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraPump.png");
  /** The pump. */
  private JostraPump pump;
 
  /**
   * Constructor for panel. 
   */
  public JostraPumpPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
    // draws the image as background
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.8f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 23));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat pumpFormat = new DecimalFormat("0.000");
    String text = "" + pump.getRpm();
    int textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 265 - textWidth, 305);
    text = pumpFormat.format(pump.getFlow());
    textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 349 - textWidth, 305);
  }

  /**
   * Gets the pump.
   *
   * @return the pump
   */
  public JostraPump getPump() {
    return pump;
  }

  /**
   * Sets the pump.
   *
   * @param pump the pump to set
   */
  public void setPump(JostraPump pump) {
    this.pump = pump;
  }
}
