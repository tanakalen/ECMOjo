package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA listener. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public interface JostraOverviewListener {

  /**
   * Called when the component got selected.
   * 
   * @param component  The selected component.
   */
  void componentSelected(JostraComponent component);
}
