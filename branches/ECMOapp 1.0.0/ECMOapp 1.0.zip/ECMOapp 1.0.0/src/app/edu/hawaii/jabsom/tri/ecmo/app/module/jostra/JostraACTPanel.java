package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Image;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA ACT panel. 
 *
 * @author   king
 * @since    February 12, 2007
 */
public class JostraACTPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraACT.png");
  /** The act. */
  private JostraACT act;
  
  /**
   * Constructor for panel. 
   */
  public JostraACTPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    // draws the image as background
    Graphics2D g2d = (Graphics2D) g;
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.8f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 54));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat actFormat = new DecimalFormat("####.###");
    String text = actFormat.format(act.getValue());
    int textWidth = g2d.getFontMetrics().stringWidth(text);
    g2d.drawString(text, 309 - textWidth, 356);
  }

  /**
   * Gets the act.
   *
   * @return the act
   */
  public JostraACT getAct() {
    return act;
  }

  /**
   * Sets the act.
   *
   * @param act the act to set
   */
  public void setAct(JostraACT act) {
    this.act = act;
  }
}
