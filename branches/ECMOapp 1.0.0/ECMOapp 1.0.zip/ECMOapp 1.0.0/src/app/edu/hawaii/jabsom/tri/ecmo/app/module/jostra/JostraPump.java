package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA pump. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraPump implements JostraComponent {
  /** The rpm. */
  private int rpm;
  /** The flow (liter per min). */
  private double flow;
  
  /**
   * Gets the rpm.
   *
   * @return the rpm
   */
  public int getRpm() {
    return rpm;
  }
  /**
   * Sets the rpm.
   *
   * @param rpm the rpm to set
   */
  public void setRpm(int rpm) {
    this.rpm = rpm;
  }
  /**
   * Gets the flow.
   *
   * @return the flow
   */
  public double getFlow() {
    return flow;
  }
  /**
   * Sets the flow.
   *
   * @param flow the flow to set
   */
  public void setFlow(double flow) {
    this.flow = flow;
  }
  
  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "Pump";
  }
}
