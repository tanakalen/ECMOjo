package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;
import java.awt.Graphics;

/**
 * The JOSTRA control panel. 
 *
 * @author   king
 * @since    January 16, 2007
 */
public class JostraPanel extends JPanel implements JostraOverviewListener {

  /** The overview panel. */
  private JostraOverviewPanel overviewPanel;
  /** The component panel. */
  private JostraComponentPanel componentPanel = null;
  
  
  /**
   * Constructor for panel. 
   * 
   * @param jostra  The JOSTRA machine.
   */
  public JostraPanel(Jostra jostra) {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set panels
    overviewPanel = new JostraOverviewPanel(jostra);
    add(overviewPanel);
    
    // listen to overview selections
    overviewPanel.addListener(this);
  }
  
  /**
   * Called when component got selected. 
   * 
   * @param component  The selection.
   */
  public void componentSelected(JostraComponent component) {
    // add new panel
    JostraComponentPanel oldComponentPanel = componentPanel;
    componentPanel = new JostraComponentPanel(component);
    componentPanel.setLocation(10, 60);
    add(componentPanel);
    if (oldComponentPanel != null) {
      remove(oldComponentPanel);
    }
    
    // redraw
    revalidate();
    repaint();
  }

  /**
   * Draws the children.
   * 
   * @param g  Where to draw to.
   */
  protected void paintChildren(Graphics g) {
    int width = getWidth();
    int height = getHeight();
    
    // add set overview position
    int width0 = overviewPanel.getWidth();
    int height0 = overviewPanel.getHeight();
    overviewPanel.setLocation(width - width0, height - height0 - 20);
    
    // draw recursively
    super.paintChildren(g);
  } 
}
