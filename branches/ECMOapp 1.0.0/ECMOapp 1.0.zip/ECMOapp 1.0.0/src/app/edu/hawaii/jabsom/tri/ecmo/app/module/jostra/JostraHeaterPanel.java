package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.DecimalFormat;

import king.lib.access.ImageLoader;

/**
 * The JOSTRA heater panel. 
 *
 * @author   king
 * @since    February 12, 2007
 */
public class JostraHeaterPanel extends JPanel {

  /** The panel image. */
  private Image panelImage = ImageLoader.getInstance().getImage("conf/image/machine/jostra/JostraHeater.png");
  /** The heater. */
  private JostraHeater heater;
  
  /**
   * Constructor for panel. 
   */
  public JostraHeaterPanel() {
    // set look
    setLayout(null);
    setOpaque(false);
    
    // set preferred size
    setPreferredSize(new Dimension(panelImage.getWidth(this), panelImage.getHeight(this)));
  }
  
  /**
   * Draws this component.
   * 
   * @param g  Where to draw to.
   */
  public void paintComponent(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
    // draws the image as background
    g2d.drawImage(panelImage, 0, 0, this);
    g2d.setColor(new Color(0.0f, 0.8f, 0.0f, 1.0f));
    g2d.setFont(new Font("sansserif", Font.BOLD, 12));
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    // draws the data
    DecimalFormat heaterFormat = new DecimalFormat("0.0");
    String text = heaterFormat.format(heater.getTemperature());
    int textWidth = g2d.getFontMetrics().stringWidth(text);    
    g2d.drawString(text, 346 - textWidth, 67);
  }
  
  /**
   * Gets the heater.
   *
   * @return the heater
   */
  public JostraHeater getHeater() {
    return heater;
  }

  /**
   * Sets the heater.
   *
   * @param heater the heater to set
   */
  public void setHeater(JostraHeater heater) {
    this.heater = heater;
  }
}