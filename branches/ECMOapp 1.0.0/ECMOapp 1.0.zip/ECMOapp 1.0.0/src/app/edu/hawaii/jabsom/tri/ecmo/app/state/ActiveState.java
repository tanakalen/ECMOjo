package edu.hawaii.jabsom.tri.ecmo.app.state;

import java.io.IOException;

import king.lib.access.Access;
import king.lib.out.Error;
import edu.hawaii.jabsom.tri.ecmo.app.module.Scenario;

/**
 * The active state. 
 *
 * @author   king
 * @since    January 11, 2007
 */
public class ActiveState extends State {

  /** The scenario. */
  private Scenario scenario;
  

  /** 
   * Constructor for state.
   */
  public ActiveState() {
    // load &start scenario
    try {
      scenario = new Scenario(Access.getInstance().getScenarioDir() + "/Scenario-0.csv");
    }
    catch (IOException e) {
      Error.out(e);
      return;
    }
    scenario.start();
  }
  
  /**
   * Returns the scenario.
   * 
   * @return  The scenario.
   */
  public Scenario getScenario() {
    return scenario;
  }
}
