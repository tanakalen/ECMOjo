package edu.hawaii.jabsom.tri.ecmo.app;

import king.lib.access.Access;
import king.lib.access.AccessException;
import java.awt.Color;
import javax.swing.JApplet;
import king.lib.out.Error;
import java.awt.BorderLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;

/**
 * Creates an application. 
 *
 * @author   king
 * @since    January 10, 2007
 */
public final class ECMOApp extends JApplet {

  /** The panel. */
  private static ECMOPanel panel = null;

  
  /**
   * Initializes the app with the given args.
   * 
   * @param args  The args used for initialization.
   */
  private static void initialize(String[] args) {
    panel = new ECMOPanel();
  }
  
  /** Inits the applet. */
  public void init() {
    try {
      Access.init(this);
    }
    catch (AccessException e) {
      Error.out(e);
    }
    
    initialize(getParameter("args").split(" "));

    // set layout
    getContentPane().setBackground(Color.BLACK);
    getContentPane().setLayout(new BorderLayout());
    
    // add panel
    getContentPane().add(panel, BorderLayout.CENTER);
  }
  
  /**
   * Main method.
   * 
   * @param args  The arguments
   */
  public static void main(String[] args) {
    try {
      Access.init();
    }
    catch (AccessException e) {
      Error.out(e);
    }
    
    // init
    initialize(args);
    
    // window
    JFrame window = new JFrame();
    window.setTitle("ECMO Simulation");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent event) {
        if (event.getKeyCode() == 27) {
          // exit on ESC
          System.exit(0);
        }
      }
    });
    
    // set layout
    window.getContentPane().setBackground(Color.BLACK);
    window.getContentPane().setLayout(new BorderLayout());
    
    // add panel
    window.getContentPane().add(panel, BorderLayout.CENTER);
    
    // and show
    window.setSize(1024, 768);
    window.setUndecorated(true);
    window.setVisible(true);
  }
}
