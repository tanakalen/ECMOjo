package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA flow meter. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraFlowMeter implements JostraComponent {

  /** The flow (liter per min). */
  private double flow;

  /**
   * Gets the flow.
   *
   * @return the flow
   */
  public double getFlow() {
    return flow;
  }

  /**
   * Sets the flow.
   *
   * @param flow the flow to set
   */
  public void setFlow(double flow) {
    this.flow = flow;
  }
  
  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "Flow Meter";
  }
}