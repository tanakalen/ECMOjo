package edu.hawaii.jabsom.tri.ecmo.app;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import king.lib.out.Error;
import edu.hawaii.jabsom.tri.ecmo.app.state.StateMachine;
import edu.hawaii.jabsom.tri.ecmo.app.state.State;
import edu.hawaii.jabsom.tri.ecmo.app.state.ActiveState;
import edu.hawaii.jabsom.tri.ecmo.app.state.ActiveStatePanel;

/**
 * The main panel. 
 *
 * @author   king
 * @since    January 10, 2007
 */
public class ECMOPanel extends JPanel {

  /** The state machine of this panel. */
  private StateMachine stateMachine;

  /** The old panel. */
  private JPanel oldPanel = null;
  
  
  /**
   * Constructor for panel. 
   */
  public ECMOPanel() {
    // init state machine
    stateMachine = new StateMachine();
    
    // set layout
    setLayout(new BorderLayout());
    
    // update panel
    update();
  }
  
  /**
   * Updates the panel based on state machine.
   */
  public void update() {
    JPanel newPanel;
    State state = stateMachine.currentState();
    if (state instanceof ActiveState) {
      newPanel = new ActiveStatePanel((ActiveState)stateMachine.currentState());
    }
    else {
      Error.out("State not supported: " + state);
      newPanel = oldPanel;
    }
    
    // replace old with new
    if (oldPanel != null) {
      remove(oldPanel);
    }
    add(newPanel, BorderLayout.CENTER);
    oldPanel = newPanel;
  }
}
