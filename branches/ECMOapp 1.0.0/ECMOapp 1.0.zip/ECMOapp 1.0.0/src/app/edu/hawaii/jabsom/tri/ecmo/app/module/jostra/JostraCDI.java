package edu.hawaii.jabsom.tri.ecmo.app.module.jostra;

/**
 * The JOSTRA CDI. 
 *
 * @author   king
 * @since    January 23, 2007
 */
public class JostraCDI implements JostraComponent {
  
  /** The pH. */
  private double pH;
  /** The pCO2. */
  private double pCO2;
  /** The pO2. */
  private double pO2;
  /** The temperature. */
  private double temperature;
  /** The HCO3. */
  private double hCO3;
  /** The BE. */
  private double bE;
  /** The Saturation (calc). */
  private double saturation;
  /** The Hct. */
  private double hct;
  /** The Hgb. */
  private double hgb;
  /** The SO2. */
  private double sO2;
  /** The K. */
  private double k;
  
  /**
   * Gets the BE value.
   * 
   * @return the bE
   */
  public double getBE() {
    return bE;
  }
  
  /**
   * Sets the BE value.
   * 
   * @param bE the BE to set
   */
  public void setBE(double bE) {
    this.bE = bE;
  }
  
  /**
   * Gets the HCO3 value.
   * 
   * @return the hCO3
   */
  public double getHCO3() {
    return hCO3;
  }
  
  /**
   * Sets the HCO3 value.
   * 
   * @param hCO3 the HCO3 to set
   */
  public void setHCO3(double hCO3) {
    this.hCO3 = hCO3;
  }
  
  /**
   * Gets the Hct value.
   * 
   * @return the hct
   */
  public double getHct() {
    return hct;
  }
  
  /**
   * Sets the Hct value.
   * 
   * @param hct the Hct to set
   */
  public void setHct(double hct) {
    this.hct = hct;
  }
  
  /**
   * Gets the Hgb value.
   * 
   * @return the hgb
   */
  public double getHgb() {
    return hgb;
  }
  
  /**
   * Sets the Hgb value.
   * 
   * @param hgb the Hgb to set
   */
  public void setHgb(double hgb) {
    this.hgb = hgb;
  }
  
  /**
   * Gets the K value.
   * 
   * @return the K   */
  public double getK() {
    return k;
  }
  
  /**
   * Sets the K value.
   * 
   * @param k the K to set
   */
  public void setK(double k) {
    this.k = k;
  }
  
  /**
   * Gets the pCO2 value.
   * 
   * @return the pCO2
   */
  public double getPCO2() {
    return pCO2;
  }
  
  /**
   * Gets the BE value.
   * 
   * @param pCO2 the pCO2 to set
   */
  public void setPCO2(double pCO2) {
    this.pCO2 = pCO2;
  }
  
  /**
   * Gets the pH value.
   * 
   * @return the pH
   */
  public double getPH() {
    return pH;
  }
  
  /**
   * Sets the pH value.
   * 
   * @param pH the pH to set
   */
  public void setPH(double pH) {
    this.pH = pH;
  }
  
  /**
   * Gets the pO2 value.
   * 
   * @return the pO2
   */
  public double getPO2() {
    return pO2;
  }
  
  /**
   * Sets the pO2 value.
   * 
   * @param pO2 the pO2 to set
   */
  public void setPO2(double pO2) {
    this.pO2 = pO2;
  }
  
  /**
   * Gets the saturation value.
   * 
   * @return the saturation
   */
  public double getSaturation() {
    return saturation;
  }
  
  /**
   * Sets the saturation value.
   *
   * @param saturation the saturation to set
   */
  public void setSaturation(double saturation) {
    this.saturation = saturation;
  }
  
  /**
   * Gets the SO2 value.
   * 
   * @return the sO2
   */
  public double getSO2() {
    return sO2;
  }
  
  /**
   * Sets the SO2 value.
   * 
   * @param sO2 the SO2 to set
   */
  public void setSO2(double sO2) {
    this.sO2 = sO2;
  }
  
  /**
   * Gets the temperature.
   * 
   * @return the temperature
   */
  public double getTemperature() {
    return temperature;
  }
  
  /**
   * Sets the temperature.
   * 
   * @param temperature the temperature to set
   */
  public void setTemperature(double temperature) {
    this.temperature = temperature;
  }
  
  /**
   * Returns the name of the component.
   * 
   * @return  The name.
   */
  public String getName() {
    return "CDI";
  }
}
