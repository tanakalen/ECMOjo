package edu.hawaii.jabsom.tri.ecmo.web.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
import org.apache.log4j.Logger;

/**
 * Controller to handle connection requests.
 * 
 * @author Christoph Aschwandne
 */
public class UploadController implements Controller {

  /**
   * Handles a client request.
   * 
   * @param request  The request from the client.
   * @param response  The response that we need to work with.
   * @return  The new view to show or null if we handled it through the response object.
   * @throws ServletException  If something with the servlet goes wrong handling the request.
   * @throws IOException  If something with IO goes wrong handling the request.
   */
  public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) 
      throws ServletException, IOException {

    // log connection
    Logger logger = Logger.getLogger(UploadController.class);
    logger.info("Connection from: " + request.getRemoteAddr());
    logger.debug("Connection from: " + request.getRemoteAddr() + " / Data-Size: " + request.getContentLength());
    response.getWriter().write("AO-Web-Test");

    return null;
  }
}
